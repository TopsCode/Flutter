<?php
 include('dbConnect.php');
 
 
 $Id= $_POST['id'];
 $Name= $_POST['product_name'];
 $Email = $_POST['product_price'];
 $Title = $_POST['product_description'];
 $Details = $_POST['product_quantity'];


$Sql_Query = "UPDATE product SET product_name= '$Name', product_price = '$Email', product_description = '$Title', product_quantity = '$Details'  WHERE id = '$Id'";

 if(mysqli_query($con,$Sql_Query))
{
    
 echo 'Record Updated Successfully';
}
else
{
 echo 'Something went wrong';
}
 
 mysqli_close($con);
?>