<?php
include('dbConnect.php');

 $sql = "SELECT * FROM product";
 
 $r = mysqli_query($con,$sql);
$response = array();
 
while ($row = mysqli_fetch_array($r))
 {
       // $value = array();
        $value["id"] = $row["id"];
        $value["product_name"] = $row["product_name"];
        $value["product_price"] = $row["product_price"];
          $value["product_description"] = $row["product_description"];
            $value["product_quantity"] = $row["product_quantity"];
       
        
        array_push($response, $value);
    }

    // echoing JSON response
    echo json_encode($response);
    mysqli_close($con);
 
 
?>