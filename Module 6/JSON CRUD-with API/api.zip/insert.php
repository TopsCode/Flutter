<?php
 
 include('dbConnect.php');

 $product_name = $_POST['product_name'];
 $product_price = $_POST['product_price'];
 $product_description =$_POST['product_description'];
 $product_quantity=$_POST['product_quantity'];
 
if($product_name=="" &&  $product_price=="" &&  $product_description=="" && $product_quantity=="")
{
       echo '0';
}
else
{ 
  $sql = "INSERT INTO product (product_name,product_price,product_description,product_quantity) VALUES (' $product_name','$product_price','$product_description','$product_quantity')";
//echo $sql;
    $ex=mysqli_query($con,$sql);
    

}

 ?>